# Task 4 – Interactive Sales & Financial Dashboard

## Project objective
Build an interactive business dashboard that helps stakeholders monitor sales, profit, growth, and regional/product performance.

## Included files
- `sales_financial_dataset.csv` – 650 rows of **synthetic practice data** covering 2024–2025.
- `PowerBI_DAX_Measures.txt` – starter DAX measures and Date table setup.
- `PowerBI_Theme.json` – consistent dashboard color theme for Power BI.
- `Dashboard_Build_Guide.md` – step-by-step dashboard layout and interaction guide.
- `Task4_Dashboard_Summary.pptx` – editable presentation summary.

## Build in Power BI Desktop (free)
1. Open Power BI Desktop and choose **Get data > Text/CSV**.
2. Import `sales_financial_dataset.csv`; rename the query/table to `Sales`.
3. Set `Order_Date` to Date, `Discount` to Decimal Number, and monetary fields to Decimal Number.
4. Create the Date table and measures using `PowerBI_DAX_Measures.txt`.
5. Create the relationship `Date[Date]` (1) → `Sales[Order_Date]` (*), then mark Date as the date table.
6. Import the theme using **View > Themes > Browse for themes** and select `PowerBI_Theme.json`.
7. Build the visuals described in `Dashboard_Build_Guide.md`.
8. Save your report as `Task4_Sales_Dashboard.pbix`.

## Suggested dashboard visuals
- KPI cards: Total Sales, Total Profit, Profit Margin, Total Orders.
- Line chart: monthly Sales and Profit trend.
- Clustered bar chart: Sales by Region.
- Bar chart: Profit by Category.
- Donut chart: Sales by Channel.
- Matrix: Category → Product with Sales, Profit, and Units Sold.
- Slicers: Year, Region, Segment, Category, Channel.

## Important
This is a ready-to-build Power BI project pack, not a `.pbix` report. Open it in Power BI Desktop and save the finished report as a PBIX file. Dataset values are synthetic and should be labelled as sample data in your submission; do not present them as real company results.
