# Dashboard Build Guide

## Page 1 – Executive Overview
**Top row:** four Card visuals – Total Sales, Total Profit, Profit Margin, Total Orders.

**Middle row:**
- Line chart: Axis = Date[Year-Month], Values = Total Sales and Total Profit.
- Clustered bar: Y-axis = Region, X-axis = Total Sales.
- Donut: Legend = Channel, Values = Total Sales.

**Bottom row:**
- Bar chart: Axis = Category, Values = Total Profit.
- Matrix: Rows = Category, Product; Values = Total Sales, Total Profit, Units Sold.

## Filters and interactivity
Add slicers for Date[Year], Region, Segment, Category, and Channel. Use Format > Edit interactions to confirm slicers filter all relevant visuals. Add a clear-filters button using a bookmark if desired. Turn on data labels where they improve readability; avoid clutter.

## Design
- Canvas: 16:9.
- Use a light background, dark text, and the imported blue/teal/orange theme.
- Keep KPI cards aligned and use consistent number formats (currency for Sales/Profit, percentage for margin).
- Use descriptive titles and meaningful tooltips.
- Add a page title: “Sales & Financial Performance”.

## Quality checks
- Confirm totals match the source CSV.
- Test every slicer and cross-filter.
- Check that dates sort chronologically (sort Year-Month by a numeric year-month column if needed).
- Verify Profit = Sales - Cost and investigate any unexpected negative profit.
- Add a footer: “Practice dataset – synthetic data”.
